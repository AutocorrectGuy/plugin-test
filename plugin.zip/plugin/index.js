/**
 * @typedef {Object} Color
 * @property {string | null} original
 * @property {string} modified
 * @property {boolean} isOriginal
 * @property {boolean} hasInitialised
 */

/** @type {Color} */
const color = {
  original: null,
  modified: '#00ff00',
  isOriginal: true,
  hasInitialised: false,
}

const toggleColor = async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  chrome.scripting.executeScript(
    {
      target: { tabId: tab.id },
      func: (color) => {
        if (!color.hasInitialised) {
          color.original = document.body.style.backgroundColor
          color.hasInitialised = true
        }
        color.isOriginal = !color.isOriginal
        const newColor = color.isOriginal ? color.original : color.modified
        document.body.style.backgroundColor = newColor
        return color
      },
      args: [color],
    },
    (results) =>
      results && results[0].result && Object.assign(color, results[0].result)
  )
}

const currentColorDiv = document.getElementById('current-color')

document.getElementById('myButton').addEventListener('click', () => {
  toggleColor().then(() => {
    const currentColor = color.isOriginal ? color.original : color.modified
    currentColorDiv.innerText = color.isOriginal ? 'Original' : 'Green'
    currentColorDiv.style.backgroundColor = currentColor
  })
})
